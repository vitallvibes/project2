const express = require("express");
const path = require("path");
const cors = require("cors");

const app = express();

// Enable CORS if needed
app.use(cors());

// Middleware to parse JSON
app.use(express.json());

// Serve static files from the "public" folder
app.use(express.static(path.join(__dirname, "public")));

// Route to serve index0.html (keeping your file name)
app.get("/", (req, res) => {
    res.sendFile(path.resolve(__dirname, "public", "index0.html"));
});

// Start the frontend server
const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
    console.log(`✅ Frontend Server is running at: http://localhost:${PORT}`);
});
