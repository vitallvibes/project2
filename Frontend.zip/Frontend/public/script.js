document.getElementById("login-form").addEventListener("submit", async function(event) {
    event.preventDefault(); // Prevent default form submission

    const username = document.getElementById("username").value.trim();
    const password = document.getElementById("password").value.trim();

    if (!username || !password) {
        alert("Please enter both username and password.");
        return;
    }

    try {
        const response = await fetch("http://localhost:3000/auth/login", { // Update with actual API endpoint
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ username, password })
        });

        const data = await response.json();

        if (response.ok) {
            alert("Login successful! Redirecting...");
            window.location.href = "dashboard.html"; // Redirect to the next page
        } else {
            throw new Error(data.message || "Invalid username or password.");
        }
    } catch (error) {
        alert("Login failed: " + error.message);
    }
});

// Password Visibility Toggle
document.getElementById("togglePassword").addEventListener("click", function () {
    const passwordInput = document.getElementById("password");
    if (passwordInput.type === "password") {
        passwordInput.type = "text";
        this.classList.replace("fa-eye-slash", "fa-eye"); // Change icon
    } else {
        passwordInput.type = "password";
        this.classList.replace("fa-eye", "fa-eye-slash");
    }
});
