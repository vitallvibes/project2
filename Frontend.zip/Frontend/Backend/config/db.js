const mysql = require('mysql2');

const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',   // Change if you use a different username
  password: 'Aishu@123',   // Add your MySQL password
  database: 'WebEase'  // Make sure this database exists
});

connection.connect((err) => {
  if (err) {
    console.error('Database connection failed: ', err);
    return;
  }
  console.log('Connected to MySQL database!');
});

module.exports = connection;
