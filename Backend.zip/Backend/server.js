const express = require("express");
const cors = require("cors");
const mysql = require("mysql");
const session = require("express-session");
const MySQLStore = require("express-mysql-session")(session);
const bcrypt = require("bcrypt"); // Secure password handling
const path = require("path");
const dotenv = require("dotenv");

dotenv.config(); // Load environment variables

const app = express();

// 🔹 Middleware
app.use(cors({
    origin: "http://localhost:3000", // Adjust for frontend origin
    credentials: true
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static("public"));

// 🔹 Database Connection
const db = mysql.createConnection({
    host: process.env.DB_HOST || "localhost",
    user: process.env.DB_USER || "root",
    password: process.env.DB_PASSWORD || "Aishu@123",
    database: process.env.DB_NAME || "webease"
});

db.connect(err => {
    if (err) {
        console.error("❌ Database connection failed:", err);
    } else {
        console.log("✅ Connected to MySQL");
    }
});

// 🔹 Session Store in MySQL
const sessionStore = new MySQLStore({}, db);
app.use(session({
    secret: process.env.SESSION_SECRET || "your_secret_key",
    resave: false,
    saveUninitialized: false,
    store: sessionStore,
    cookie: { secure: false, httpOnly: true }
}));

// 🔹 Home Route (For Testing)
app.get("/", (req, res) => {
    res.send("✅ Backend is working!");
});

// 🔹 Login Route
app.post("/auth/login", (req, res) => {
    const { username, password } = req.body;
    console.log("🔑 Login Attempt:", { username });

    if (!username || !password) {
        return res.status(400).json({ message: "❌ Missing credentials" });
    }

    db.query("SELECT * FROM users WHERE username = ?", [username], async (err, results) => {
        if (err) {
            console.error("❌ Database Error:", err);
            return res.status(500).json({ message: "Server error" });
        }

        if (results.length > 0) {
            const user = results[0];

            const passwordMatch = await bcrypt.compare(password, user.password);
            if (!passwordMatch) {
                return res.status(401).json({ message: "❌ Invalid credentials" });
            }

            req.session.user = { id: user.id, username: user.username };
            return res.json({ success: true, redirect: "/index1.html" });
        } else {
            return res.status(401).json({ message: "❌ User not found" });
        }
    });
});

// 🔹 Session Check Route (for frontend session validation)
app.get("/auth/check-session", (req, res) => {
    res.json({ loggedIn: !!req.session.user });
});

// 🔹 Middleware to Protect Routes
app.use((req, res, next) => {
    if (!req.session.user && !req.path.endsWith("index0.html") && !req.path.startsWith("/auth")) {
        return res.redirect("/index0.html");
    }
    next();
});

// 🔹 Serve Protected Pages
const pages = ["index1.html", "index2.html", "index3.html", "index4.html", "index5.html", "index6.html", "index7.html"];
pages.forEach(page => {
    app.get(`/${page}`, (req, res) => {
        res.sendFile(path.join(__dirname, "public", page));
    });
});

// 🔹 Logout Route
app.post("/auth/logout", (req, res) => {
    req.session.destroy(err => {
        if (err) {
            return res.status(500).json({ success: false, message: "❌ Logout failed" });
        }
        res.clearCookie("connect.sid"); // Clear session cookie
        res.json({ success: true });
    });
});

// 🔹 Start Server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`🚀 Server is running on http://localhost:${PORT}`);
});
