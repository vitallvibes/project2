const express = require("express");
const bcrypt = require("bcrypt");
const db = require("./db"); // Import your database connection
const router = express.Router();

// Default Admin Credentials
const DEFAULT_USERNAME = "admin";
const DEFAULT_PASSWORD = "password123";

// Function to Check and Insert Default User
const ensureDefaultUser = async () => {
    db.query("SELECT * FROM users WHERE username = ?", [DEFAULT_USERNAME], async (err, results) => {
        if (err) {
            console.error("Error checking default user:", err);
            return;
        }
        if (results.length === 0) {
            const hashedPassword = await bcrypt.hash(DEFAULT_PASSWORD, 10);
            db.query("INSERT INTO users (username, password) VALUES (?, ?)", [DEFAULT_USERNAME, hashedPassword], (err) => {
                if (err) console.error("Error inserting default user:", err);
                else console.log("Default admin user created.");
            });
        }
    });
};

ensureDefaultUser();

// Login Route
router.post("/login", (req, res) => {
    const { username, password } = req.body;
    console.log("Login Attempt:", { username, password });

    if (!username || !password) {
        return res.status(400).json({ message: "Missing credentials" });
    }

    db.query("SELECT * FROM users WHERE username = ?", [username], async (err, results) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ message: "Server error" });
        }

        if (results.length > 0) {
            const user = results[0];
            const passwordMatch = await bcrypt.compare(password, user.password);
            
            if (passwordMatch) {
                req.session.user = user;
                return res.json({ success: true, redirect: "/index1.html" });
            }
        }

        return res.status(401).json({ message: "Invalid credentials" });
    });
});

// Session Check Route
router.get("/check-session", (req, res) => {
    res.json({ loggedIn: !!req.session.user });
});

// Logout Route
router.post("/logout", (req, res) => {
    req.session.destroy(err => {
        if (err) {
            return res.status(500).json({ success: false, message: "Logout failed" });
        }
        res.clearCookie("connect.sid");
        res.json({ success: true });
    });
});

module.exports = router;
